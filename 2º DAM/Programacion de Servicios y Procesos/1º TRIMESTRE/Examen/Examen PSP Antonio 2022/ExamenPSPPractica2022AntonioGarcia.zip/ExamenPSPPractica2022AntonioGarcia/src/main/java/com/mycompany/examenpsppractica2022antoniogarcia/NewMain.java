package com.mycompany.examenpsppractica2022antoniogarcia;

public class NewMain {

    public static void main(String[] args) {
        // TODO code application logic here
        //EJERCICIO 1 a)
        Concurrente conejo = new Concurrente("conejo");
        Concurrente tortuga = new Concurrente("tortuga");
        
        conejo.start();
        tortuga.start();
        
        /*EJERCICIO 1 b)
        //Al utilizar tortuga.join(), se da prioridad a este hilo y conejo.start()
        //no comenzara a ejecutarse hasta que tortuga haya acabado.
        tortuga.start();
        try {
            tortuga.join();
        } catch (InterruptedException ex) {
            Logger.getLogger(NewMain.class.getName()).log(Level.SEVERE, null, ex);
        }
        conejo.start();*/
    }
    
}
