
package com.mycompany.examenpsppractica2022antoniogarcia;

import java.util.logging.Level;
import java.util.logging.Logger;

public class Concurrente extends Thread{
    
    private int distancia = 10;
    private String animal;

    public Concurrente(String animal) {
        this.animal = animal;
    }
    
    public String getAnimal() {
        return animal;
    }

    public void setAnimal(String animal) {
        this.animal = animal;
    }

    public int getDistancia() {
        return distancia;
    }

    public void setDistancia(int distancia) {
        this.distancia = distancia;
    }

    @Override
    public void run() {
        for (int i = 0; i < distancia; i++) {
            if(this.animal == "conejo"){
                try {
                    System.out.println("Conejo: Metro "+i);
                    Thread.sleep(1000);
                } catch (InterruptedException ex) {
                    Logger.getLogger(Concurrente.class.getName()).log(Level.SEVERE, null, ex);
                }
            }else{
                try {
                    System.out.println("Tortuga: Metro "+i);
                    Thread.sleep(5000);
                } catch (InterruptedException ex) {
                    Logger.getLogger(Concurrente.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }
    
}
