package com.mycompany.examenpsppractica2022antoniogarciaejercicio3;

import java.util.ArrayList;
import java.util.List;

public class TestNodo {
    public static void main(String[] args) {
		List<Integer> lista = new ArrayList<Integer>();
		double valor=Math.random()*100;
		int total = (int) valor;
		for (int i=0;i<total;i++){
			double num = Math.random()*100;
			int numero=(int) num;
			lista.add(numero);
		}
		System.out.println(lista);
		Nodo n1 = new Nodo(lista);
		n1.start();
		try {
			n1.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(n1.lista);
	}
}
