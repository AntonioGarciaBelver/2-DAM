package com.mycompany.aplicacionesswing;

import java.awt.Font;
import java.awt.GraphicsEnvironment;
import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;

public class Fuente extends javax.swing.JDialog {

    private EditorTexto ventanaPadre;

    private String fuente = "Arial";
    private String estilo;
    private int tamano = 12;
    
//    private String[] fontTypes = GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames();
//    private String[] fontStyles = {"Arial", "Bold", "Italic"};
//    private Integer[] fontSizes = {10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 32, 34, 36, 38};

    public Fuente(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        ventanaPadre = (EditorTexto) parent;

        initComponents();
    }

    public String getCurrentFont() {
        System.out.println(fuente);
        return fuente;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        comboFuente = new javax.swing.JComboBox<>();
        comboEstilo = new javax.swing.JComboBox<>();
        comboTamano = new javax.swing.JComboBox<>();
        jPanel1 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        textoPrueba = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jButton4 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();

        jButton1.setText("jButton1");

        jButton2.setText("jButton2");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Fuente");
        setMinimumSize(new java.awt.Dimension(365, 360));
        setModal(true);
        setPreferredSize(new java.awt.Dimension(350, 350));
        setResizable(false);

        jPanel2.setMinimumSize(new java.awt.Dimension(350, 500));
        jPanel2.setPreferredSize(new java.awt.Dimension(200, 50));

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel1.setText("    Fuente: ");
        jLabel1.setMaximumSize(new java.awt.Dimension(41, 30));
        jLabel1.setMinimumSize(new java.awt.Dimension(41, 30));
        jLabel1.setPreferredSize(new java.awt.Dimension(115, 70));
        jPanel2.add(jLabel1);

        jLabel2.setText("Estilo de fuente:");
        jLabel2.setPreferredSize(new java.awt.Dimension(115, 16));
        jPanel2.add(jLabel2);

        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel3.setText("Tamaño:");
        jLabel3.setPreferredSize(new java.awt.Dimension(90, 16));
        jPanel2.add(jLabel3);

        getContentPane().add(jPanel2, java.awt.BorderLayout.NORTH);

        jPanel4.setPreferredSize(new java.awt.Dimension(350, 100));
        jPanel4.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 10, 5));

        comboFuente.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Arial", "Sans Serif", "Helvetica", "Brutalism" }));
        comboFuente.setMinimumSize(new java.awt.Dimension(110, 22));
        comboFuente.setPreferredSize(new java.awt.Dimension(110, 22));
        comboFuente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboFuenteActionPerformed(evt);
            }
        });
        jPanel4.add(comboFuente);

        comboEstilo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Normal", "Curvisva", "Negrita", "Cursiva negrita" }));
        comboEstilo.setMinimumSize(new java.awt.Dimension(110, 22));
        comboEstilo.setPreferredSize(new java.awt.Dimension(110, 22));
        comboEstilo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboEstiloActionPerformed(evt);
            }
        });
        jPanel4.add(comboEstilo);

        comboTamano.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "10", "12", "14", "16", "18", "20", "22", "24", "26", "28", "30", "32", "34", "36", "38" }));
        comboTamano.setMinimumSize(new java.awt.Dimension(95, 22));
        comboTamano.setPreferredSize(new java.awt.Dimension(90, 22));
        comboTamano.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboTamanoActionPerformed(evt);
            }
        });
        jPanel4.add(comboTamano);

        getContentPane().add(jPanel4, java.awt.BorderLayout.CENTER);

        jPanel1.setMinimumSize(new java.awt.Dimension(381, 32));

        jPanel5.setPreferredSize(new java.awt.Dimension(150, 55));

        textoPrueba.setText("AaBbYyZz");
        textoPrueba.setPreferredSize(new java.awt.Dimension(53, 40));
        jPanel5.add(textoPrueba);

        jPanel1.add(jPanel5);

        jButton4.setText("Aceptar");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton4);

        jButton3.setText("Cancelar");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton3);

        jPanel1.add(jPanel3);

        getContentPane().add(jPanel1, java.awt.BorderLayout.PAGE_END);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void comboFuenteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboFuenteActionPerformed
        // TODO add your handling code here:
        String tipo = (String) comboFuente.getSelectedItem();
        Font fuenteTipo = new Font(tipo, 0, tamano);
        textoPrueba.setFont(fuenteTipo);
    }//GEN-LAST:event_comboFuenteActionPerformed

    private void comboEstiloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboEstiloActionPerformed
        // TODO add your handling code here:
        this.estilo = (String) comboEstilo.getSelectedItem();
    }//GEN-LAST:event_comboEstiloActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        Font myFont1 = new Font(fuente, Font.BOLD, tamano);
        textoPrueba.setFont(myFont1);
    }//GEN-LAST:event_jButton4ActionPerformed

    private void comboTamanoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboTamanoActionPerformed
        // TODO add your handling code here:
        String x = (String) comboTamano.getSelectedItem();
        tamano = Integer.parseInt(x);
        Font fuenteTipo = new Font("Arial", 0, tamano);
        textoPrueba.setFont(fuenteTipo);
    }//GEN-LAST:event_comboTamanoActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_jButton3ActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Fuente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Fuente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Fuente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Fuente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                Fuente dialog = new Fuente(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> comboEstilo;
    private javax.swing.JComboBox<String> comboFuente;
    private javax.swing.JComboBox<String> comboTamano;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JLabel textoPrueba;
    // End of variables declaration//GEN-END:variables
}
