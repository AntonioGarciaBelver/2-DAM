/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import static java.sql.Statement.RETURN_GENERATED_KEYS;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import models.Pedido;

/**
 *
 * @author loren
 */
public class PedidoDAOMySQL implements PedidoDAO{

    private static final String GET_QUERY = "select * from pedido where idpedido=?";
    private static final String INSERT_QUERY = """
                INSERT INTO `pedido` 
                        (`idpedido`, `fecha`, `cliente`, `producto`) 
                VALUES  (NULL, ?, ?, ?,?);""";
    private static final String GETALL_QUERY = "SELECT * FROM pedido ORDER BY idpedido";
    private static final String DELETE_ID_QUERY = "DELETE FROM pedido WHERE idpedido = ?";
    private static final String UPDATE_QUERY = """
                UPDATE `pedido` SET 
                    `fecha` = ?,
                    `cliente` = ?,
                    `producto` = ?
                WHERE `pedido`.`idpedido` = ?""";
    private static final String GETALL_BY_NOMBRE_QUERY = "SELECT * FROM pedido WHERE cliente = ?";
    
    private static Connection conexion = Conexion.getConexion();

    public PedidoDAOMySQL(){
    }
    
    
    
    
    @Override
    public Pedido get(Integer id) {
        try(var pst = conexion.prepareStatement(GET_QUERY)){
            
            pst.setInt(1, id);
            
            ResultSet resultado = pst.executeQuery();
            
            if(resultado.next()){
                var pedido = new Pedido();
                pedido.setIdpedido(resultado.getInt("idpedido") );
                pedido.setFecha( resultado.getString("fecha") );
                pedido.setCliente(resultado.getString("cliente") );
                pedido.setProducto( resultado.getInt("producto") );
                return pedido;
            }else{
                return null;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(PedidoDAOMySQL.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    @Override
    public void add(Pedido p) {
        try( var pst = conexion.prepareStatement(INSERT_QUERY, RETURN_GENERATED_KEYS)){
            
            pst.setString(1, p.getFecha() );
            pst.setString(2, p.getCliente() );
            pst.setInt(3, p.getProducto() );
            
            if (pst.executeUpdate() > 0){

                var keys = pst.getGeneratedKeys();
                keys.next();
                
                //p.setId(keys.getInt(1));
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(PedidoDAOMySQL.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }

    @Override
    public void update(Pedido p) {
        
        try(var pst = conexion.prepareStatement(UPDATE_QUERY)){
            
            pst.setString(1, p.getFecha());
            pst.setString(2, p.getCliente());
            pst.setInt(3, p.getProducto());
            
            if( pst.executeUpdate()== 0){
                Logger.getLogger(PedidoDAOMySQL.class.getName()).severe("Pedido no existe.");
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(PedidoDAOMySQL.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public ArrayList<Pedido> getAll() {
        var salida = new ArrayList<Pedido>();
        
        try( var pst = conexion.prepareStatement(GETALL_QUERY)){
            
            ResultSet resultado = pst.executeQuery();
            
            while(resultado.next()){
                var pedido = new Pedido();
                pedido.setIdpedido(resultado.getInt("idpedido") );
                pedido.setFecha( resultado.getString("fecha") );
                pedido.setCliente(resultado.getString("cliente") );
                pedido.setProducto( resultado.getInt("producto") );
                salida.add(pedido);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(PedidoDAOMySQL.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return salida;
    }

    @Override
    public void delete(Pedido p) {
        deleteById(p.getIdpedido());
    }

    @Override
    public void deleteById(Integer id) {
        try( var pst = conexion.prepareStatement(DELETE_ID_QUERY)){
        
            pst.setInt(1, id);
            
            if(pst.executeUpdate()==0){
                Logger.getLogger(PedidoDAOMySQL.class.getName()).warning("Pedido no existe");
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(PedidoDAOMySQL.class.getName()).log(Level.SEVERE, null, ex);
        }    
    }

    @Override
    public ArrayList<Pedido> getAllByNombre(String nombre) {
        var salida = new ArrayList<Pedido>();
        
        try( var pst = conexion.prepareStatement(GETALL_BY_NOMBRE_QUERY)){
            
            pst.setString(1, nombre);
            ResultSet resultado = pst.executeQuery();
            
            while(resultado.next()){
                var pedido = new Pedido();
                pedido.setIdpedido(resultado.getInt("idpedido") );
                pedido.setFecha( resultado.getString("fecha") );
                pedido.setCliente(resultado.getString("cliente") );
                pedido.setProducto( resultado.getInt("producto") );
                salida.add(pedido);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(PedidoDAOMySQL.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return salida;
    }
    
}
