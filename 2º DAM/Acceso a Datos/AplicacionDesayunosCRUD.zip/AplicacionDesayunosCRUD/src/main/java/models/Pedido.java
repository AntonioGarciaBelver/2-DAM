package models;

import java.io.Serializable;

/**
 *
 * @author Antonio y Loren
 */
public class Pedido implements Serializable {

    private Integer idpedido;
    private String fecha;
    private String cliente;
    private Integer producto;

    public Pedido() {
        
    }

    public Integer getIdpedido() {
        return idpedido;
    }

    public void setIdpedido(Integer idpedido) {
        this.idpedido = idpedido;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getCliente() {
        return cliente;
    }

    public void setCliente(String cliente) {
        this.cliente = cliente;
    }

    public Integer getProducto() {
        return producto;
    }

    public void setProducto(Integer producto) {
        this.producto = producto;
    }

    @Override
    public String toString() {
        return "Pedido{" + "idpedido=" + idpedido + ", fecha=" + fecha + ", cliente=" + cliente + ", producto=" + producto + '}';
    }

    
}

