package com.mycompany.aplicaciondesayunoscrud;

import controller.CartaDAOMySQL;
import controller.PedidoDAOMySQL;
import controller.Conexion;
import java.sql.Connection;
import java.util.ArrayList;
import models.Carta;

/**
 *
 * @author Antonio y Loren
 */
public class Main {

    public static Connection conexion;
    static PedidoDAOMySQL daoPedido = new PedidoDAOMySQL();
    
    public static void main(String[] args) {
        conexion  = Conexion.getConexion();
        
        

//        Carta carta = new Carta("Hola", "Hola", 1, "s");
//        daoCarta.add(carta);
        
//        ArrayList<Carta> productos = new ArrayList();
//        productos = c.getAll();
//        System.out.println(productos);
    }
    
}
