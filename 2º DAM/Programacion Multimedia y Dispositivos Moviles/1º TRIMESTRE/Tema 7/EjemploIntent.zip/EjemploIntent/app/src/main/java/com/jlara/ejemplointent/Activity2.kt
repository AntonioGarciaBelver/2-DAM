package com.jlara.ejemplointent

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText

class Activity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_2)
        val nombre = intent.getStringExtra("nombre")
        val sueldo = intent.getDoubleExtra("sueldo",0.0)
        val etNombre = findViewById<EditText>(R.id.etNombre)
        val etSalario = findViewById<EditText>(R.id.etSalario)
        nombre.also { etNombre.setText(it) }
        sueldo.also { etSalario.setText(it.toString()) }
        val btnEnviar = findViewById<Button>(R.id.btnEnviar)
        btnEnviar.setOnClickListener{
            val intent = Intent()
            val name = etNombre.text.toString()
            val salary = etSalario.text.toString().toDouble()
            intent.putExtra("nombre", name)
            intent.putExtra("sueldo", salary)
            setResult(RESULT_OK, intent)
            finish()
        }
    }
}