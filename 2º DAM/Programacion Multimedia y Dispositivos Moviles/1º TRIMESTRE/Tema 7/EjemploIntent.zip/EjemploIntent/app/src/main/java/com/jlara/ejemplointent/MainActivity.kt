package com.jlara.ejemplointent

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.View.OnClickListener
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.ActivityResult
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : AppCompatActivity(), OnClickListener {

    private lateinit var intentLaunch: ActivityResultLauncher<Intent>
    private var nombre:String? = ""
    private var sueldo:Double? = 0.0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val btnAbrir = findViewById<Button>(R.id.btnAbrir)
        btnAbrir.setOnClickListener(this)
        val tvTexto = findViewById<TextView>(R.id.tvTexto)
        tvTexto.text = "Datos no obtenidos"
        intentLaunch = registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()) { result: ActivityResult ->
            if (result.resultCode == RESULT_OK) {
                nombre = result.data?.extras?.getString("nombre")
                sueldo = result.data?.extras?.getDouble("sueldo")
                tvTexto.text = "Nombre: $nombre - Sueldo: $sueldo"
            }
        }
    }

    override fun onClick(p0: View?) {
        val intent = Intent(this,Activity2::class.java)
        intent.putExtra("nombre", nombre)
        intent.putExtra("sueldo", sueldo)
        intentLaunch.launch(intent)
    }
}