package com.jlara.ejemplogmapskotlin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.google.android.gms.maps.*
import com.google.android.gms.maps.GoogleMap.OnMapClickListener
import com.google.android.gms.maps.GoogleMap.OnMarkerClickListener
import com.google.android.gms.maps.model.BitmapDescriptorFactory

import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.jlara.ejemplogmapskotlin.databinding.ActivityMapsBinding
import java.util.*

class MapsActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap
    private lateinit var binding: ActivityMapsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMapsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap

        // Add a marker in Sydney and move the camera
        val sydney = LatLng(-34.0, 151.0)
        mMap.addMarker(MarkerOptions().position(sydney).title("Marker in Sydney"))
        mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney))
        mMap.mapType = GoogleMap.MAP_TYPE_HYBRID
        var cameraPosition = CameraPosition(LatLng(36.719726, -4.421611), 1.0f, 45.0f, 0.0f)
        var cameraUpdate = CameraUpdateFactory.newCameraPosition(cameraPosition)
        mMap.animateCamera(cameraUpdate)

        cameraPosition=mMap.cameraPosition
        val posicion="Latitud:" + cameraPosition.target.latitude + " Longitud:" + cameraPosition.target.longitude

        val objetivo = LatLng(40.734434, -74.014545)
        cameraPosition =
            CameraPosition.Builder().target(objetivo).zoom(16.0f).bearing(45.0f).tilt(70.0f).build()
        cameraUpdate = CameraUpdateFactory.newCameraPosition(cameraPosition)
        mMap.moveCamera(cameraUpdate)

        val cesur = LatLng(36.7194937132025, -4.365499019622804)
        cameraPosition =
            CameraPosition.Builder().target(cesur).zoom(16.0f).bearing(45.0f).tilt(70.0f).build()
        cameraUpdate = CameraUpdateFactory.newCameraPosition(cameraPosition)
        mMap.addMarker(
            MarkerOptions().position(LatLng(36.7194937132025, -4.365499019622804))
                .icon(BitmapDescriptorFactory.fromResource(R.drawable.cesur))
                .title("Cesur Málaga Este").snippet("CESUR")
        )
        mMap.animateCamera(cameraUpdate)

        mMap.setOnMarkerClickListener { marker ->
            val toast = Toast.makeText(
                this@MapsActivity,
                marker.title, Toast.LENGTH_SHORT
            )
            toast.show()
            false
        }

        mMap.setOnMapClickListener { latLng ->
            val toast = Toast.makeText(
                this@MapsActivity,
                "Latitud:" + latLng.latitude +
                        " Longitud:" + latLng.longitude,
                Toast.LENGTH_SHORT
            )
            toast.show()
        }
    }


}